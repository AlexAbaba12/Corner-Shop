# Corner Shop

A Django storefront with product browsing, cart, checkout, order tracking, customer
notifications, an admin panel, and a token-authenticated REST API. Docker Compose runs
the app with PostgreSQL.

## Step-by-step setup

### 1. Install the prerequisites

- Install and start [Docker Desktop](https://www.docker.com/products/docker-desktop/) (Windows or macOS), or install Docker Engine and the Compose plugin (Linux).
- Make sure Docker is running before continuing.

You do not need to install Python or PostgreSQL separately; Docker runs both the app and
database for local development.

### 2. Get the project files

Download or copy the project folder to your computer and extract it if it is a ZIP file.
Open a terminal in the folder that contains `docker-compose.yml` and `manage.py` (the
`shop` folder). When sharing the project, include `.env.example` but do not include your
personal `.env` file or local database files.

### 3. Create your local settings file

Copy `.env.example` to `.env`:

**Windows PowerShell**

```powershell
Copy-Item .env.example .env
```

**macOS / Linux**

```bash
cp .env.example .env
```

Open `.env` in a text editor. Before the first startup, replace
`DJANGO_SUPERUSER_PASSWORD` with a private password. You can also change the store name,
currency, admin username, and email there. Keep `.env` private; do not post or send it
publicly. For a local demo, the other defaults can be left as-is.

### 4. Build and start the shop

Run this from the `shop` folder:

```bash
docker compose up --build
```

The first build may take a few minutes. Leave this terminal window open while using the
shop. On startup, Docker waits for PostgreSQL, applies database migrations, prepares
static files, and creates the admin account from the `.env` settings if it does not
already exist. Set the admin password before the first startup; changing it in `.env`
later does not change an existing account's password.

### 5. Open the pages

- Storefront: <http://localhost:8000/>
- Admin panel: <http://localhost:8000/admin/>
- Interactive API documentation: <http://localhost:8000/api/> (also available at <http://localhost:8000/api/docs/>)

The `.env.example` defaults are username `admin` and password `admin12345`. These
credentials are used only when creating the admin account for the first time; use the
password you configured in `.env` if you changed it, or if the account already existed.
Change the default password before using the app beyond a local demo. Demo products are
not added by default. To load the sample products, stop the app, set
`SEED_DEMO_DATA=1` in `.env`, then start it again with `docker compose up`. The default
currency is Philippine pesos (`₱`).

### 6. Stop or restart the shop

- To stop the foreground app, press **Ctrl+C** in the terminal running Docker Compose.
- To start it again later, open a terminal in the `shop` folder and run
  `docker compose up`.
- To stop the containers in the background, run `docker compose down`. Your database
  volume is kept, so orders and settings remain when you start the app again.

### Troubleshooting

- **Docker connection error:** start Docker Desktop, wait until it says Docker is
  running, then retry `docker compose up --build`.
- **Port 8000 is already in use:** change the host side of the `ports` entry in
  `docker-compose.yml`, for example from `8000:8000` to `8001:8000`, then open
  <http://localhost:8001/>.
- **Changes do not appear:** leave Compose running and refresh the browser. After
  changing dependencies or Docker configuration, stop the app and run
  `docker compose up --build` again.

This setup runs a private local copy on each computer. Your friend should receive the
project files and follow these steps on their own computer. The `localhost` links only
work on the computer running the app; to let someone access a shared shop over the
internet, deploy it to a hosting service and configure production security first.

## Customer accounts and support

- Account registration accepts an optional profile photo, shown beside the username in the navigation bar.
- Customer support requests can be submitted at `/support/` and reviewed in Django Admin under Support requests.
- Set `SUPPORT_EMAIL` in `.env` to receive support-request notifications. Configure SMTP settings before using email in production.

## Orders and notifications

- Order history and order details show each product, quantity, unit price, and line total.
- Customers can view order status and shipment schedule updates at `/notifications/`. Status changes to paid, shipped, delivered, or cancelled are recorded for the signed-in customer.
- Staff can update an order's status, shipment date/time, and expected delivery date/time from its detail page in Django Admin.

## API quick tour

```bash
# create an account and get a token
curl -X POST localhost:8000/api/auth/register/ -H 'Content-Type: application/json' \
  -d '{"username":"ada","email":"ada@example.com","password":"a-long-pass-123"}'

# browse (public): ?search=, ?category=<slug>, ?in_stock=true, ?ordering=price
curl 'localhost:8000/api/products/?category=desk&ordering=price'

# place an order (reserves stock immediately)
curl -X POST localhost:8000/api/orders/ -H 'Authorization: Token <key>' \
  -H 'Content-Type: application/json' -d '{
    "full_name":"Ada Buyer","email":"ada@example.com","address":"1 Main St",
    "city":"Springfield","postal_code":"12345",
    "items":[{"product":1,"quantity":2}]}'

curl -X POST localhost:8000/api/orders/1/pay/    -H 'Authorization: Token <key>'
curl -X POST localhost:8000/api/orders/1/cancel/ -H 'Authorization: Token <key>'
```

| Endpoint | Who | Purpose |
|---|---|---|
| `POST /api/auth/register/` | anyone | Create account, returns token |
| `POST /api/auth/token/` | anyone | Exchange username and password for a token |
| `GET /api/categories/` | anyone | List categories |
| `GET /api/products/`, `GET /api/products/<slug>/` | anyone | Browse, search, filter |
| `POST/PUT/PATCH/DELETE /api/products/...` | staff | Manage the catalog |
| `GET/POST /api/orders/`, `GET /api/orders/<id>/` | signed in | Your orders |
| `POST /api/orders/<id>/pay/`, `.../cancel/` | signed in | Pay or cancel a pending order |

## Tests

```bash
docker compose run --rm web python manage.py test
```

## Layout

- `store/`: models, order logic (`services.py`), session cart, website views and templates
- `api/`: DRF serializers, viewsets, routes
- `config/`: settings and URLs
- Order creation, cancellation, and stock handling live in `store/services.py` so the
  website and the API behave identically.

## Before going live

- Set `DJANGO_DEBUG=0`, a long random `DJANGO_SECRET_KEY`, `DJANGO_ALLOWED_HOSTS`, and
  `DJANGO_CSRF_TRUSTED_ORIGINS` (for example `https://shop.example.com`).
- Replace the simulated "Pay now" (`store/services.py: mark_paid`) with a real provider
  such as Stripe: create a checkout session when the order is placed and call `mark_paid`
  from the provider's webhook.
- Serve `/media/` from nginx or object storage, and put TLS in front of gunicorn.
- Remove the `.:/app` bind mount from `docker-compose.yml` for production.
