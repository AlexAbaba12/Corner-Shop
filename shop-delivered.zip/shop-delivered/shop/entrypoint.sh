#!/bin/sh
set -e

# Create migrations for the store app if they are missing or out of date,
# then apply everything. Commit the generated store/migrations/0001_initial.py.
python manage.py makemigrations store --noinput
python manage.py migrate --noinput
python manage.py collectstatic --noinput

if [ -n "$DJANGO_SUPERUSER_USERNAME" ] && [ -n "$DJANGO_SUPERUSER_PASSWORD" ]; then
  python manage.py createsuperuser --noinput \
    --email "${DJANGO_SUPERUSER_EMAIL:-admin@example.com}" || true
fi

if [ "$SEED_DEMO_DATA" = "1" ]; then
  python manage.py seed
fi

exec "$@"
