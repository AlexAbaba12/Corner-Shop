from django.conf import settings
from django.contrib import admin
from django.urls import include, path, re_path
from django.views.static import serve

from store import views as store_views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("api.urls")),
    path("accounts/register/", store_views.register, name="register"),
    path("accounts/", include("django.contrib.auth.urls")),
    path("", include("store.urls")),
    # Uploaded product images. Fine for a single-container deployment;
    # put nginx or object storage in front of /media/ for real traffic.
    re_path(r"^media/(?P<path>.*)$", serve, {"document_root": settings.MEDIA_ROOT}),
]
