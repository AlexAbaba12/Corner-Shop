from decimal import Decimal
from datetime import datetime, timezone as datetime_timezone
from io import BytesIO
from tempfile import TemporaryDirectory

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse
from PIL import Image

from .models import Category, CustomerProfile, Order, OrderNotification, Product, SupportRequest
from .services import OrderError, cancel_order, create_order

User = get_user_model()

SHIPPING = {
    "full_name": "Ada Buyer",
    "email": "ada@example.com",
    "address": "1 Main St",
    "city": "Springfield",
    "postal_code": "12345",
}


def make_product(name="Mug", price="10.00", stock=5):
    category, _ = Category.objects.get_or_create(name="Kitchen", defaults={"slug": "kitchen"})
    return Product.objects.create(category=category, name=name, price=Decimal(price), stock=stock)


class ServiceTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user("ada", password="pw-12345-xyz")

    def test_create_order_reserves_stock_and_totals(self):
        product = make_product(stock=5)
        order = create_order(self.user, SHIPPING, [(product.pk, 2)])
        product.refresh_from_db()
        self.assertEqual(product.stock, 3)
        self.assertEqual(order.total, Decimal("20.00"))

    def test_insufficient_stock_rolls_back(self):
        product = make_product(stock=1)
        with self.assertRaises(OrderError):
            create_order(self.user, SHIPPING, [(product.pk, 2)])
        product.refresh_from_db()
        self.assertEqual(product.stock, 1)
        self.assertEqual(Order.objects.count(), 0)

    def test_cancel_restores_stock(self):
        product = make_product(stock=5)
        order = create_order(self.user, SHIPPING, [(product.pk, 2)])
        cancel_order(order)
        product.refresh_from_db()
        self.assertEqual(product.stock, 5)

    def test_slug_is_unique(self):
        a = make_product(name="Same name")
        b = make_product(name="Same name")
        self.assertNotEqual(a.slug, b.slug)


class WebFlowTests(TestCase):
    def test_default_currency_uses_pesos(self):
        product = make_product()
        response = self.client.get(reverse("store:product_list"))
        self.assertContains(response, "₱10.00")

    def test_registration_accepts_profile_photo(self):
        image_bytes = BytesIO()
        Image.new("RGB", (2, 2), color="blue").save(image_bytes, format="PNG")
        photo = SimpleUploadedFile("avatar.png", image_bytes.getvalue(), content_type="image/png")

        with TemporaryDirectory() as media_dir, override_settings(MEDIA_ROOT=media_dir):
            response = self.client.post(
                reverse("register"),
                {
                    "username": "newbuyer",
                    "email": "newbuyer@example.com",
                    "password1": "Strong-pass-12345",
                    "password2": "Strong-pass-12345",
                    "photo": photo,
                },
            )
            self.assertContains(
                self.client.get(reverse("store:product_list")),
                "/media/profiles/avatar.png",
            )

        self.assertRedirects(response, reverse("store:product_list"))
        profile = CustomerProfile.objects.get(user__username="newbuyer")
        self.assertTrue(profile.photo.name.startswith("profiles/"))

    def test_support_request_is_saved(self):
        response = self.client.post(
            reverse("store:support"),
            {
                "name": "Shopper",
                "email": "shopper@example.com",
                "subject": "Order question",
                "message": "I have a question about my order.",
            },
        )

        self.assertRedirects(response, reverse("store:support"))
        ticket = SupportRequest.objects.get()
        self.assertEqual(ticket.email, "shopper@example.com")
        self.assertEqual(ticket.status, SupportRequest.Status.OPEN)

    def test_admin_link_is_only_visible_to_staff(self):
        regular_user = User.objects.create_user("shopper", password="pw-12345-xyz")
        self.client.force_login(regular_user)
        response = self.client.get(reverse("store:product_list"))
        self.assertNotContains(response, ">Admin</a>")

        regular_user.is_staff = True
        regular_user.save(update_fields=["is_staff"])
        response = self.client.get(reverse("store:product_list"))
        self.assertContains(response, ">Admin</a>")

    def test_staff_product_admin_loads_store_admin_theme(self):
        staff_user = User.objects.create_superuser("manager", email="manager@example.com", password="pw-12345-xyz")
        self.client.force_login(staff_user)

        response = self.client.get(reverse("admin:store_product_changelist"))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "/static/store/admin.css?v=7")
        self.assertContains(response, "Corner Shop Admin")
        self.assertContains(response, "Add product")

    def test_superuser_can_create_backup_admin_account(self):
        manager = User.objects.create_superuser(
            "owner", email="owner@example.com", password="pw-12345-xyz"
        )
        self.client.force_login(manager)
        self.assertContains(
            self.client.get(reverse("admin:index")), "Create admin account"
        )

        response = self.client.post(
            reverse("admin:auth_user_add"),
            {
                "username": "backup-admin",
                "email": "backup@example.com",
                "password1": "Strong-backup-12345",
                "password2": "Strong-backup-12345",
                "_save": "Save",
            },
        )

        self.assertEqual(response.status_code, 302)
        backup = User.objects.get(username="backup-admin")
        self.assertTrue(backup.is_staff)
        self.assertTrue(backup.is_superuser)
        self.assertTrue(backup.check_password("Strong-backup-12345"))
        accounts = self.client.get(reverse("admin:auth_user_changelist"))
        self.assertContains(accounts, "Set/reset password")
        self.assertContains(
            accounts,
            reverse("admin:auth_user_password_change", args=[backup.pk]),
        )
        password_form = self.client.get(
            reverse("admin:auth_user_password_change", args=[backup.pk])
        )
        self.assertEqual(password_form.status_code, 200)
        self.assertContains(password_form, 'name="password1"')
        self.assertContains(password_form, 'name="password2"')

    def test_non_superuser_cannot_manage_admin_accounts(self):
        staff_user = User.objects.create_user(
            "staff", email="staff@example.com", password="pw-12345-xyz", is_staff=True
        )
        self.client.force_login(staff_user)

        dashboard = self.client.get(reverse("admin:index"))
        add_account = self.client.get(reverse("admin:auth_user_add"))

        self.assertNotContains(dashboard, "Create admin account")
        self.assertEqual(add_account.status_code, 403)

    def test_google_sign_in_is_removed(self):
        for url_name in ("login", "register"):
            response = self.client.get(reverse(url_name))
            self.assertNotContains(response, "Continue with Google")

    def test_repeated_failed_signins_lock_out_credentials(self):
        user = User.objects.create_user("lockout-user", password="Correct-pass-12345")
        login_url = reverse("login")

        for _ in range(5):
            self.client.post(login_url, {"username": user.username, "password": "wrong-password"})

        response = self.client.post(
            login_url, {"username": user.username, "password": "Correct-pass-12345"}
        )

        self.assertNotIn("_auth_user_id", self.client.session)
        self.assertIn(response.status_code, (200, 403, 429))

    def test_valid_customer_signin_still_works(self):
        user = User.objects.create_user("valid-login", password="Correct-pass-12345")

        response = self.client.post(
            reverse("login"),
            {"username": user.username, "password": "Correct-pass-12345"},
        )

        self.assertRedirects(response, reverse("store:product_list"))
        self.assertEqual(str(self.client.session.get("_auth_user_id")), str(user.pk))

    def test_browse_cart_checkout(self):
        product = make_product(stock=4)
        self.assertContains(self.client.get(reverse("store:product_list")), "Mug")
        self.client.post(reverse("store:cart_add", args=[product.pk]), {"quantity": 2})
        self.assertContains(self.client.get(reverse("store:cart")), "20.00")

        # checkout requires login
        response = self.client.get(reverse("store:checkout"))
        self.assertEqual(response.status_code, 302)

        User.objects.create_user("ada", password="pw-12345-xyz")
        self.client.force_login(User.objects.get(username="ada"))
        checkout = self.client.get(reverse("store:checkout"))
        self.assertContains(checkout, 'name="payment_method"')
        self.assertContains(checkout, "PayPal")
        response = self.client.post(
            reverse("store:checkout"), {**SHIPPING, "payment_method": "paypal"}
        )
        order = Order.objects.get()
        self.assertEqual(order.payment_method, Order.PaymentMethod.PAYPAL)
        self.assertRedirects(response, reverse("store:order_detail", args=[order.pk]))
        product.refresh_from_db()
        self.assertEqual(product.stock, 2)

    def test_pending_order_can_be_cancelled_from_order_list(self):
        user = User.objects.create_user("buyer", password="pw-12345-xyz")
        product = make_product(stock=4)
        order = create_order(user, SHIPPING, [(product.pk, 2)])
        self.client.force_login(user)

        response = self.client.get(reverse("store:order_list"))
        self.assertContains(response, "Cancel order")
        response = self.client.post(reverse("store:order_cancel", args=[order.pk]))

        self.assertRedirects(response, reverse("store:order_list"))
        order.refresh_from_db()
        product.refresh_from_db()
        self.assertEqual(order.status, Order.Status.CANCELLED)
        self.assertEqual(product.stock, 4)
        self.assertEqual(
            order.notifications.get().message,
            f"Order #{order.pk} status updated to Cancelled.",
        )

    def test_order_list_shows_product_name_quantity_and_price(self):
        user = User.objects.create_user("buyer", password="Strong-pass-12345")
        product = make_product(name="Travel Mug", price="12.50")
        create_order(user, SHIPPING, [(product.pk, 2)])
        self.client.force_login(user)

        response = self.client.get(reverse("store:order_list"))

        self.assertContains(response, "Travel Mug")
        self.assertContains(response, "Qty 2")
        self.assertContains(response, "₱12.50 each")

    def test_status_change_creates_a_customer_notification(self):
        user = User.objects.create_user("buyer", password="Strong-pass-12345")
        product = make_product()
        order = create_order(user, SHIPPING, [(product.pk, 1)])
        order.status = Order.Status.SHIPPED
        order.save(update_fields=["status"])
        self.client.force_login(user)

        response = self.client.get(reverse("store:notification_list"))

        self.assertContains(response, f"Order #{order.pk} status updated to Shipped.")
        self.assertContains(response, reverse("store:order_detail", args=[order.pk]))
        self.assertEqual(OrderNotification.objects.filter(user=user, order=order).count(), 1)

    def test_delivery_schedule_change_creates_notification_with_expected_date(self):
        user = User.objects.create_user("buyer", password="Strong-pass-12345")
        product = make_product()
        order = create_order(user, SHIPPING, [(product.pk, 1)])
        expected_delivery = datetime(2026, 11, 15, 12, 0, tzinfo=datetime_timezone.utc)
        order.expected_delivery_at = expected_delivery
        order.save(update_fields=["expected_delivery_at"])

        notification = order.notifications.get()

        self.assertIn("Expected delivery:", notification.message)
        self.assertIn("Nov. 15, 2026", notification.message)
        self.client.force_login(user)
        self.assertContains(
            self.client.get(reverse("store:notification_list")),
            notification.message,
        )

    def test_notification_page_only_shows_the_signed_in_users_notifications(self):
        owner = User.objects.create_user("owner", password="Strong-pass-12345")
        other = User.objects.create_user("other", password="Strong-pass-12345")
        product = make_product()
        owner_order = create_order(owner, SHIPPING, [(product.pk, 1)])
        other_order = create_order(other, SHIPPING, [(product.pk, 1)])
        owner_order.status = Order.Status.DELIVERED
        owner_order.save(update_fields=["status"])
        other_order.status = Order.Status.CANCELLED
        other_order.save(update_fields=["status"])
        self.client.force_login(owner)

        response = self.client.get(reverse("store:notification_list"))

        self.assertContains(response, f"Order #{owner_order.pk} status updated to Delivered.")
        self.assertNotContains(response, f"Order #{other_order.pk} status updated to Cancelled.")

    def test_admin_can_change_order_status_and_notify_customer(self):
        staff_user = User.objects.create_superuser(
            "manager", email="manager@example.com", password="Strong-pass-12345"
        )
        customer = User.objects.create_user("buyer", password="Strong-pass-12345")
        product = make_product()
        order = create_order(customer, SHIPPING, [(product.pk, 1)])
        order.status = Order.Status.PAID
        order.save(update_fields=["status"])
        order.notifications.all().delete()
        self.client.force_login(staff_user)
        changelist_url = reverse("admin:store_order_changelist")

        response = self.client.get(changelist_url)
        self.assertContains(response, 'name="form-0-status"')
        change_url = reverse("admin:store_order_change", args=[order.pk])
        change_page = self.client.get(change_url)
        self.assertContains(change_page, "Shipment date and time")
        self.assertContains(change_page, "Expected delivery date and time")
        response = self.client.post(
            change_url,
            {
                "status": Order.Status.PAID,
                "shipped_at_0": "",
                "shipped_at_1": "",
                "expected_delivery_at_0": "2026-11-15",
                "expected_delivery_at_1": "12:00:00",
                "items-TOTAL_FORMS": "1",
                "items-INITIAL_FORMS": "1",
                "items-MIN_NUM_FORMS": "0",
                "items-MAX_NUM_FORMS": "1000",
                "items-0-id": str(order.items.get().pk),
                "items-0-order": str(order.pk),
                "_save": "Save",
            },
        )
        self.assertEqual(response.status_code, 302)
        order.refresh_from_db()
        self.assertEqual(order.expected_delivery_at, datetime(
            2026, 11, 15, 12, 0, tzinfo=datetime_timezone.utc
        ))
        self.assertIn("Expected delivery:", order.notifications.get().message)
        order.notifications.all().delete()

        response = self.client.post(
            changelist_url,
            {"action": "mark_shipped", "_selected_action": [str(order.pk)], "index": "0"},
        )

        self.assertEqual(response.status_code, 302)
        order.refresh_from_db()
        self.assertEqual(order.status, Order.Status.SHIPPED)
        self.assertIsNotNone(order.shipped_at)
        self.assertIn(
            f"Order #{order.pk} status updated to Shipped.",
            order.notifications.get().message,
        )
        self.assertIn("Shipment date and time:", order.notifications.get().message)

    def test_payment_endpoint_does_not_fake_success_without_provider(self):
        user = User.objects.create_user("buyer", password="pw-12345-xyz")
        product = make_product()
        order = create_order(user, SHIPPING, [(product.pk, 1)])
        self.client.force_login(user)

        response = self.client.post(reverse("store:order_pay", args=[order.pk]))

        self.assertRedirects(response, reverse("store:order_detail", args=[order.pk]))
        order.refresh_from_db()
        self.assertEqual(order.status, Order.Status.PENDING)

    def test_cannot_view_someone_elses_order(self):
        owner = User.objects.create_user("owner", password="pw-12345-xyz")
        User.objects.create_user("other", password="pw-12345-xyz")
        product = make_product()
        order = create_order(owner, SHIPPING, [(product.pk, 1)])
        self.client.force_login(User.objects.get(username="other"))
        response = self.client.get(reverse("store:order_detail", args=[order.pk]))
        self.assertEqual(response.status_code, 404)
