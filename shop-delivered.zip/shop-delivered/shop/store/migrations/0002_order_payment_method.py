from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("store", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="order",
            name="payment_method",
            field=models.CharField(
                choices=[
                    ("card", "Credit or debit card"),
                    ("visa", "Visa"),
                    ("mastercard", "Mastercard"),
                    ("amex", "American Express"),
                    ("discover", "Discover"),
                    ("jcb", "JCB"),
                    ("unionpay", "UnionPay"),
                    ("paypal", "PayPal"),
                    ("apple_pay", "Apple Pay"),
                    ("google_pay", "Google Pay"),
                    ("shop_pay", "Shop Pay"),
                    ("amazon_pay", "Amazon Pay"),
                    ("samsung_pay", "Samsung Pay"),
                    ("cash_app", "Cash App Pay"),
                    ("bank_transfer", "Bank transfer"),
                    ("ach", "ACH bank transfer"),
                    ("sepa", "SEPA direct debit"),
                    ("open_banking", "Open banking"),
                    ("ideal", "iDEAL"),
                    ("bancontact", "Bancontact"),
                    ("blik", "BLIK"),
                    ("pix", "Pix"),
                    ("upi", "UPI"),
                    ("interac", "Interac"),
                    ("klarna", "Klarna"),
                    ("afterpay", "Afterpay / Clearpay"),
                    ("affirm", "Affirm"),
                    ("zip", "Zip"),
                    ("cash_on_delivery", "Cash on delivery"),
                    ("gift_card", "Gift card"),
                    ("store_credit", "Store credit"),
                    ("cryptocurrency", "Cryptocurrency"),
                ],
                default="card",
                max_length=24,
            ),
        ),
    ]