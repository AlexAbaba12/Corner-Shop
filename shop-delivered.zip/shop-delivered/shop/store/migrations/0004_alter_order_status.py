from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('store', '0003_customerprofile_supportrequest'),
    ]

    operations = [
        migrations.AlterField(
            model_name='order',
            name='status',
            field=models.CharField(choices=[('pending', 'Pending payment'), ('paid', 'Paid'), ('shipped', 'Shipped'), ('delivered', 'Delivered'), ('cancelled', 'Cancelled')], default='pending', max_length=12),
        ),
    ]
