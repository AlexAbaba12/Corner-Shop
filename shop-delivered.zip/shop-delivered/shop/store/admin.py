from django import forms
from django.contrib import admin, messages
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from django.contrib.auth.forms import UserCreationForm
from django.db import transaction
from django.urls import reverse
from django.utils import timezone
from django.utils.html import format_html

from .models import (
    Category,
    CustomerProfile,
    Order,
    OrderItem,
    Product,
    SupportRequest,
)

User = get_user_model()

admin.site.site_header = "Corner Shop Admin"
admin.site.site_title = "Corner Shop Control Panel"
admin.site.index_title = "Store management"


class AdminAccountCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ("username", "email")

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data["email"]
        user.is_staff = True
        user.is_superuser = True
        if commit:
            user.save()
        return user


admin.site.unregister(User)


@admin.register(User)
class AdminAccountAdmin(DjangoUserAdmin):
    add_form = AdminAccountCreationForm
    add_fieldsets = (
        ("Create a backup administrator", {
            "classes": ("wide",),
            "fields": ("username", "email", "password1", "password2"),
            "description": "This creates a full administrator account. Store the credentials securely.",
        }),
    )
    list_display = ("username", "email", "password_reset_link", "is_active", "last_login")
    list_display_links = ("username",)
    list_filter = ("is_active", "is_superuser", "last_login")
    search_fields = ("username", "email", "first_name", "last_name")
    ordering = ("username",)
    list_per_page = 25
    save_on_top = True

    def get_queryset(self, request):
        return super().get_queryset(request).filter(is_staff=True)

    def has_module_permission(self, request):
        return request.user.is_superuser

    def has_view_permission(self, request, obj=None):
        return request.user.is_superuser

    def has_add_permission(self, request):
        return request.user.is_superuser

    def has_change_permission(self, request, obj=None):
        return request.user.is_superuser

    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser

    def save_model(self, request, obj, form, change):
        if not change:
            obj.is_staff = True
            obj.is_superuser = True
        super().save_model(request, obj, form, change)

    @admin.display(description="Password recovery")
    def password_reset_link(self, obj):
        url = reverse("admin:auth_user_password_change", args=[obj.pk])
        return format_html('<a class="admin-password-reset" href="{}">Set/reset password</a>', url)


@admin.register(CustomerProfile)
class CustomerProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "photo")
    search_fields = ("user__username", "user__email")
    list_select_related = ("user",)
    ordering = ("user__username",)


@admin.register(SupportRequest)
class SupportRequestAdmin(admin.ModelAdmin):
    list_display = ("subject", "name", "email", "status", "created")
    list_display_links = ("subject",)
    list_editable = ("status",)
    list_filter = ("status", "created")
    search_fields = ("subject", "name", "email", "message")
    date_hierarchy = "created"
    readonly_fields = ("user", "name", "email", "subject", "message", "created")
    list_per_page = 25


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "product_count")
    search_fields = ("name", "slug")
    prepopulated_fields = {"slug": ("name",)}

    @admin.display(description="Products")
    def product_count(self, obj):
        return obj.products.count()


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "price", "stock", "is_active", "updated")
    list_display_links = ("name",)
    list_editable = ("price", "stock", "is_active")
    list_filter = ("category", "is_active", "created")
    search_fields = ("name", "description", "category__name")
    autocomplete_fields = ("category",)
    prepopulated_fields = {"slug": ("name",)}
    readonly_fields = ("created", "updated")
    date_hierarchy = "created"
    list_per_page = 25
    save_on_top = True


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ("product", "price", "quantity")
    can_delete = False


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "full_name", "user", "status", "payment_method", "created", "order_total")
    list_display_links = ("id",)
    list_editable = ("status",)
    list_filter = ("status", "payment_method", "created")
    search_fields = ("full_name", "email", "user__username", "id")
    list_select_related = ("user",)
    date_hierarchy = "created"
    list_per_page = 25
    fieldsets = (
        ("Order status and delivery", {"fields": ("status", "shipped_at", "expected_delivery_at")}),
        ("Customer and shipping address", {
            "fields": ("user", "full_name", "email", "address", "city", "postal_code", "payment_method")
        }),
        ("Order dates", {"fields": ("created", "updated")}),
    )
    readonly_fields = (
        "user", "full_name", "email", "address", "city", "postal_code",
        "payment_method", "created", "updated",
    )
    inlines = [OrderItemInline]
    save_on_top = True
    actions = ["mark_shipped", "mark_delivered"]

    @admin.display(description="Total")
    def order_total(self, obj):
        return obj.total

    @admin.action(description="Mark selected orders as shipped")
    @transaction.atomic
    def mark_shipped(self, request, queryset):
        orders = queryset.filter(status=Order.Status.PAID)
        updated = orders.count()
        for order in orders:
            order.status = Order.Status.SHIPPED
            order.updated = timezone.now()
            order.save(update_fields=["status", "updated"])
        self.message_user(
            request,
            f"{updated} order(s) marked as shipped. Only paid orders can be shipped.",
            messages.SUCCESS if updated else messages.WARNING,
        )

    @admin.action(description="Mark selected orders as delivered")
    @transaction.atomic
    def mark_delivered(self, request, queryset):
        orders = queryset.filter(
            status__in=[Order.Status.PAID, Order.Status.SHIPPED]
        )
        updated = orders.count()
        for order in orders:
            order.status = Order.Status.DELIVERED
            order.updated = timezone.now()
            order.save(update_fields=["status", "updated"])
        self.message_user(
            request,
            f"{updated} order(s) marked as delivered. Only paid or shipped orders can be delivered.",
            messages.SUCCESS if updated else messages.WARNING,
        )
