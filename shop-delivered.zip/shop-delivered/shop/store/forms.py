from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm

from .models import CustomerProfile, Order, SupportRequest

User = get_user_model()


class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    photo = forms.ImageField(required=False, label="Profile photo")

    class Meta:
        model = User
        fields = ("username", "email")

    def save(self, commit=True):
        user = super().save(commit=commit)
        if commit:
            CustomerProfile.objects.update_or_create(
                user=user, defaults={"photo": self.cleaned_data.get("photo")}
            )
        return user


class SupportForm(forms.ModelForm):
    class Meta:
        model = SupportRequest
        fields = ("name", "email", "subject", "message")
        widgets = {"message": forms.Textarea(attrs={"rows": 5})}


class CheckoutForm(forms.ModelForm):
    PAYMENT_GROUPS = (
        ("Card", tuple((method.value, method.label) for method in (
            Order.PaymentMethod.CARD,
            Order.PaymentMethod.VISA,
            Order.PaymentMethod.MASTERCARD,
            Order.PaymentMethod.AMEX,
            Order.PaymentMethod.DISCOVER,
            Order.PaymentMethod.JCB,
            Order.PaymentMethod.UNIONPAY,
        ))),
        ("Digital wallets", tuple((method.value, method.label) for method in (
            Order.PaymentMethod.PAYPAL,
            Order.PaymentMethod.APPLE_PAY,
            Order.PaymentMethod.GOOGLE_PAY,
            Order.PaymentMethod.SHOP_PAY,
            Order.PaymentMethod.AMAZON_PAY,
            Order.PaymentMethod.SAMSUNG_PAY,
            Order.PaymentMethod.CASH_APP,
        ))),
        ("Bank payments", tuple((method.value, method.label) for method in (
            Order.PaymentMethod.BANK_TRANSFER,
            Order.PaymentMethod.ACH,
            Order.PaymentMethod.SEPA,
            Order.PaymentMethod.OPEN_BANKING,
            Order.PaymentMethod.IDEAL,
            Order.PaymentMethod.BANCONTACT,
            Order.PaymentMethod.BLIK,
            Order.PaymentMethod.PIX,
            Order.PaymentMethod.UPI,
            Order.PaymentMethod.INTERAC,
        ))),
        ("Pay over time", tuple((method.value, method.label) for method in (
            Order.PaymentMethod.KLARNA,
            Order.PaymentMethod.AFTERPAY,
            Order.PaymentMethod.AFFIRM,
            Order.PaymentMethod.ZIP,
        ))),
        ("Other", tuple((method.value, method.label) for method in (
            Order.PaymentMethod.COD,
            Order.PaymentMethod.GIFT_CARD,
            Order.PaymentMethod.STORE_CREDIT,
            Order.PaymentMethod.CRYPTO,
        ))),
    )

    payment_method = forms.ChoiceField(
        choices=PAYMENT_GROUPS,
        widget=forms.RadioSelect,
        initial=Order.PaymentMethod.CARD,
        help_text="Your selection is saved with the order. Online payment processing requires a connected provider.",
    )

    class Meta:
        model = Order
        fields = ("full_name", "email", "address", "city", "postal_code", "payment_method")
        labels = {
            "full_name": "Full name",
            "postal_code": "Postal code",
            "payment_method": "Choose a payment method",
        }
