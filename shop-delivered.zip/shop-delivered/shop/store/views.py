from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .cart import Cart
from .forms import CheckoutForm, RegisterForm, SupportForm
from .models import Category, Order, OrderNotification, Product
from .services import OrderError, cancel_order, create_order


def product_list(request):
    products = Product.objects.filter(is_active=True).select_related("category")
    query = request.GET.get("q", "").strip()
    category_slug = request.GET.get("category", "")
    if query:
        products = products.filter(Q(name__icontains=query) | Q(description__icontains=query))
    if category_slug:
        products = products.filter(category__slug=category_slug)
    page = Paginator(products, 12).get_page(request.GET.get("page"))
    return render(
        request,
        "store/product_list.html",
        {
            "page_obj": page,
            "categories": Category.objects.all(),
            "query": query,
            "active_category": category_slug,
        },
    )


def product_detail(request, slug):
    product = get_object_or_404(Product.objects.select_related("category"), slug=slug, is_active=True)
    return render(request, "store/product_detail.html", {"product": product})


def cart_detail(request):
    return render(request, "store/cart.html", {"cart": Cart(request)})


@require_POST
def cart_add(request, product_id):
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    try:
        quantity = max(1, int(request.POST.get("quantity", 1)))
    except ValueError:
        quantity = 1
    if not product.in_stock:
        messages.error(request, f"{product.name} is sold out.")
        return redirect(product)
    cart = Cart(request)
    wanted = int(cart.data.get(str(product.pk), 0)) + quantity
    in_cart = cart.add(product, quantity)
    if in_cart < wanted:
        messages.info(request, f"Only {product.stock} of {product.name} available, so that's what's in your cart.")
    else:
        messages.success(request, f"Added {product.name} to your cart.")
    return redirect("store:cart")


@require_POST
def cart_update(request, product_id):
    product = get_object_or_404(Product, pk=product_id, is_active=True)
    try:
        quantity = int(request.POST.get("quantity", 1))
    except ValueError:
        quantity = 1
    Cart(request).add(product, quantity, override=True)
    return redirect("store:cart")


@require_POST
def cart_remove(request, product_id):
    Cart(request).remove(product_id)
    return redirect("store:cart")


@login_required
def checkout(request):
    cart = Cart(request)
    if not len(cart):
        messages.info(request, "Your cart is empty.")
        return redirect("store:cart")
    if request.method == "POST":
        form = CheckoutForm(request.POST)
        if form.is_valid():
            try:
                order = create_order(request.user, form.cleaned_data, cart.as_order_items())
            except OrderError as exc:
                messages.error(request, str(exc))
                return redirect("store:cart")
            cart.clear()
            messages.success(request, f"Order #{order.pk} placed. Pay below to confirm it.")
            return redirect("store:order_detail", pk=order.pk)
    else:
        form = CheckoutForm(
            initial={"email": request.user.email, "full_name": request.user.get_full_name()}
        )
    return render(request, "store/checkout.html", {"cart": cart, "form": form})


@login_required
def order_list(request):
    orders = Order.objects.filter(user=request.user).prefetch_related("items__product")
    return render(request, "store/order_list.html", {"orders": orders})


@login_required
def notification_list(request):
    notifications = OrderNotification.objects.filter(user=request.user).select_related("order")
    return render(request, "store/notification_list.html", {"notifications": notifications})


@login_required
def order_detail(request, pk):
    order = get_object_or_404(
        Order.objects.prefetch_related("items__product"), pk=pk, user=request.user
    )
    return render(request, "store/order_detail.html", {"order": order})


@login_required
@require_POST
def order_pay(request, pk):
    order = get_object_or_404(Order, pk=pk, user=request.user)
    messages.error(
        request,
        "Payment processing is unavailable until a payment provider is connected. Your order remains pending.",
    )
    return redirect("store:order_detail", pk=order.pk)


@login_required
@require_POST
def order_cancel(request, pk):
    order = get_object_or_404(Order, pk=pk, user=request.user)
    try:
        cancel_order(order)
        messages.success(request, f"Order #{order.pk} cancelled.")
    except OrderError as exc:
        messages.error(request, str(exc))
    return redirect("store:order_list")


def register(request):
    if request.user.is_authenticated:
        return redirect("store:product_list")
    form = RegisterForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user, backend="django.contrib.auth.backends.ModelBackend")
        messages.success(request, "Account created. You're signed in.")
        return redirect("store:product_list")
    return render(request, "registration/register.html", {"form": form})


def support(request):
    initial = {}
    if request.user.is_authenticated:
        initial = {
            "name": request.user.get_full_name() or request.user.username,
            "email": request.user.email,
        }
    form = SupportForm(request.POST or None, initial=initial)
    if request.method == "POST" and form.is_valid():
        support_request = form.save(commit=False)
        if request.user.is_authenticated:
            support_request.user = request.user
        support_request.save()
        if settings.SUPPORT_EMAIL:
            send_mail(
                subject=f"Shop support: {support_request.subject}",
                message=(
                    f"From: {support_request.name} <{support_request.email}>\n\n"
                    f"{support_request.message}"
                ),
                from_email=None,
                recipient_list=[settings.SUPPORT_EMAIL],
                fail_silently=True,
            )
        messages.success(request, "Your support request was sent. We’ll get back to you by email.")
        return redirect("store:support")
    return render(request, "store/support.html", {"form": form})
