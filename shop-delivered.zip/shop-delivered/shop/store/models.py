from decimal import Decimal

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.urls import reverse
from django.utils import formats, timezone
from django.utils.text import slugify


class Category(models.Model):
    name = models.CharField(max_length=80, unique=True)
    slug = models.SlugField(max_length=90, unique=True)

    class Meta:
        ordering = ["name"]
        verbose_name_plural = "categories"

    def __str__(self):
        return self.name


class CustomerProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="customer_profile"
    )
    photo = models.ImageField(upload_to="profiles/", blank=True)

    def __str__(self):
        return f"Profile for {self.user}"


class SupportRequest(models.Model):
    class Status(models.TextChoices):
        OPEN = "open", "Open"
        IN_PROGRESS = "in_progress", "In progress"
        CLOSED = "closed", "Closed"

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="support_requests",
    )
    name = models.CharField(max_length=120)
    email = models.EmailField()
    subject = models.CharField(max_length=160)
    message = models.TextField(max_length=5000)
    status = models.CharField(max_length=16, choices=Status.choices, default=Status.OPEN)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created"]

    def __str__(self):
        return f"{self.subject} ({self.get_status_display()})"


class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="products")
    name = models.CharField(max_length=160)
    slug = models.SlugField(max_length=180, unique=True, blank=True)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    stock = models.PositiveIntegerField(default=0)
    image = models.ImageField(upload_to="products/", blank=True)
    is_active = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created", "name"]

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.name) or "product"
            slug, n = base, 2
            while Product.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base}-{n}"
                n += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse("store:product_detail", args=[self.slug])

    @property
    def in_stock(self):
        return self.stock > 0

    @property
    def placeholder_hue(self):
        """Stable hue for the placeholder shown when a product has no image."""
        return (sum(ord(c) for c in self.name) * 37) % 360


class Order(models.Model):
    class PaymentMethod(models.TextChoices):
        CARD = "card", "Credit or debit card"
        VISA = "visa", "Visa"
        MASTERCARD = "mastercard", "Mastercard"
        AMEX = "amex", "American Express"
        DISCOVER = "discover", "Discover"
        JCB = "jcb", "JCB"
        UNIONPAY = "unionpay", "UnionPay"
        PAYPAL = "paypal", "PayPal"
        APPLE_PAY = "apple_pay", "Apple Pay"
        GOOGLE_PAY = "google_pay", "Google Pay"
        SHOP_PAY = "shop_pay", "Shop Pay"
        AMAZON_PAY = "amazon_pay", "Amazon Pay"
        SAMSUNG_PAY = "samsung_pay", "Samsung Pay"
        CASH_APP = "cash_app", "Cash App Pay"
        BANK_TRANSFER = "bank_transfer", "Bank transfer"
        ACH = "ach", "ACH bank transfer"
        SEPA = "sepa", "SEPA direct debit"
        OPEN_BANKING = "open_banking", "Open banking"
        IDEAL = "ideal", "iDEAL"
        BANCONTACT = "bancontact", "Bancontact"
        BLIK = "blik", "BLIK"
        PIX = "pix", "Pix"
        UPI = "upi", "UPI"
        INTERAC = "interac", "Interac"
        KLARNA = "klarna", "Klarna"
        AFTERPAY = "afterpay", "Afterpay / Clearpay"
        AFFIRM = "affirm", "Affirm"
        ZIP = "zip", "Zip"
        COD = "cash_on_delivery", "Cash on delivery"
        GIFT_CARD = "gift_card", "Gift card"
        STORE_CREDIT = "store_credit", "Store credit"
        CRYPTO = "cryptocurrency", "Cryptocurrency"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending payment"
        PAID = "paid", "Paid"
        SHIPPED = "shipped", "Shipped"
        DELIVERED = "delivered", "Delivered"
        CANCELLED = "cancelled", "Cancelled"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="orders")
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.PENDING)
    full_name = models.CharField(max_length=120)
    email = models.EmailField()
    address = models.CharField(max_length=255)
    city = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    payment_method = models.CharField(
        max_length=24, choices=PaymentMethod.choices, default=PaymentMethod.CARD
    )
    shipped_at = models.DateTimeField("Shipment date and time", blank=True, null=True)
    expected_delivery_at = models.DateTimeField(
        "Expected delivery date and time", blank=True, null=True
    )
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-created"]

    def __str__(self):
        return f"Order #{self.pk}"

    def save(self, *args, **kwargs):
        update_fields = kwargs.get("update_fields")
        tracked_fields = None if update_fields is None else set(update_fields)
        database = kwargs.get("using") or self._state.db
        previous = None
        if self.pk and (
            tracked_fields is None
            or tracked_fields.intersection({"status", "shipped_at", "expected_delivery_at"})
        ):
            previous = (
                Order.objects.using(database)
                .filter(pk=self.pk)
                .values("status", "shipped_at", "expected_delivery_at")
                .first()
            )

        if (
            previous
            and (tracked_fields is None or "status" in tracked_fields)
            and previous["status"] != self.status
            and self.status == self.Status.SHIPPED
            and self.shipped_at is None
        ):
            self.shipped_at = timezone.now()
            if tracked_fields is not None:
                tracked_fields.add("shipped_at")
                kwargs["update_fields"] = tracked_fields

        super().save(*args, **kwargs)
        if previous:
            status = (
                self.status
                if tracked_fields is None or "status" in tracked_fields
                else previous["status"]
            )
            shipped_at = (
                self.shipped_at
                if tracked_fields is None or "shipped_at" in tracked_fields
                else previous["shipped_at"]
            )
            expected_delivery_at = (
                self.expected_delivery_at
                if tracked_fields is None or "expected_delivery_at" in tracked_fields
                else previous["expected_delivery_at"]
            )
            status_changed = status != previous["status"]
            schedule_changed = (
                shipped_at != previous["shipped_at"]
                or expected_delivery_at != previous["expected_delivery_at"]
            )
            if status_changed or schedule_changed:
                status_message = f"Order #{self.pk} status updated to {self.Status(status).label}."
                message = status_message
                if schedule_changed:
                    message = (
                        f"{status_message} Shipment schedule updated."
                        if status_changed
                        else f"Order #{self.pk} shipment schedule updated."
                    )
                    if shipped_at:
                        message += (
                            " Shipment date and time: "
                            f"{formats.date_format(timezone.localtime(shipped_at), 'N j, Y, P')}."
                        )
                    if expected_delivery_at:
                        message += (
                            " Expected delivery: "
                            f"{formats.date_format(timezone.localtime(expected_delivery_at), 'N j, Y, P')}."
                        )
                OrderNotification.objects.using(self._state.db).create(
                    user_id=self.user_id,
                    order_id=self.pk,
                    status=status,
                    message=message,
                )

    @property
    def total(self):
        return sum((item.line_total for item in self.items.all()), Decimal("0.00"))


class OrderNotification(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="order_notifications"
    )
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="notifications")
    status = models.CharField(max_length=12, choices=Order.Status.choices)
    message = models.TextField()
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created", "-pk"]

    def __str__(self):
        return self.message


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="order_items")
    price = models.DecimalField(max_digits=10, decimal_places=2)  # price at time of purchase
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.quantity} x {self.product}"

    @property
    def line_total(self):
        return self.price * self.quantity
