"""Order logic shared by the website and the REST API."""
from django.db import transaction
from django.db.models import F

from .models import Order, OrderItem, Product


class OrderError(Exception):
    """Raised when an order can't be created or changed. The message is user-facing."""


@transaction.atomic
def create_order(user, shipping, items):
    """Create an order and reserve stock.

    shipping: dict with full_name, email, address, city, postal_code
    items: iterable of (product_id, quantity)
    """
    merged = {}
    for product_id, quantity in items:
        merged[int(product_id)] = merged.get(int(product_id), 0) + int(quantity)
    if not merged:
        raise OrderError("Your cart is empty.")

    products = {
        p.pk: p
        for p in Product.objects.select_for_update().filter(pk__in=merged.keys(), is_active=True)
    }

    order = Order.objects.create(user=user, **shipping)
    for product_id, quantity in sorted(merged.items()):
        product = products.get(product_id)
        if product is None:
            raise OrderError("One of the products is no longer available.")
        if quantity < 1:
            raise OrderError("Quantities must be at least 1.")
        if product.stock < quantity:
            if product.stock == 0:
                raise OrderError(f"{product.name} is sold out.")
            raise OrderError(f"Only {product.stock} of {product.name} left.")
        product.stock -= quantity
        product.save(update_fields=["stock", "updated"])
        OrderItem.objects.create(order=order, product=product, price=product.price, quantity=quantity)
    return order


@transaction.atomic
def cancel_order(order):
    order = Order.objects.select_for_update().get(pk=order.pk)
    if order.status != Order.Status.PENDING:
        raise OrderError("Only orders that are waiting for payment can be cancelled.")
    for item in order.items.all():
        Product.objects.filter(pk=item.product_id).update(stock=F("stock") + item.quantity)
    order.status = Order.Status.CANCELLED
    order.save(update_fields=["status", "updated"])
    return order


@transaction.atomic
def mark_paid(order):
    """Placeholder payment step. Swap this for a Stripe/PayPal webhook handler."""
    order = Order.objects.select_for_update().get(pk=order.pk)
    if order.status != Order.Status.PENDING:
        raise OrderError("This order is not waiting for payment.")
    order.status = Order.Status.PAID
    order.save(update_fields=["status", "updated"])
    return order
