from decimal import Decimal

from .models import Product


class Cart:
    """Session-backed cart. Stores {product_id: quantity}; prices are always read fresh."""

    SESSION_KEY = "cart"

    def __init__(self, request):
        self.session = request.session
        self.data = dict(self.session.get(self.SESSION_KEY, {}))
        self._items = None

    def _save(self):
        self.session[self.SESSION_KEY] = self.data
        self.session.modified = True
        self._items = None

    def add(self, product, quantity=1, override=False):
        key = str(product.pk)
        current = int(self.data.get(key, 0))
        wanted = quantity if override else current + quantity
        wanted = min(wanted, product.stock)
        if wanted <= 0:
            self.data.pop(key, None)
        else:
            self.data[key] = wanted
        self._save()
        return max(wanted, 0)

    def remove(self, product_id):
        self.data.pop(str(product_id), None)
        self._save()

    def clear(self):
        self.data = {}
        self._save()

    @property
    def items(self):
        if self._items is None:
            products = Product.objects.filter(pk__in=[int(k) for k in self.data], is_active=True)
            self._items = []
            for product in products:
                quantity = min(int(self.data[str(product.pk)]), product.stock)
                if quantity > 0:
                    self._items.append(
                        {"product": product, "quantity": quantity, "line_total": product.price * quantity}
                    )
        return self._items

    def __iter__(self):
        return iter(self.items)

    def __len__(self):
        return sum(int(q) for q in self.data.values())

    @property
    def total(self):
        return sum((item["line_total"] for item in self.items), Decimal("0.00"))

    def as_order_items(self):
        return [(item["product"].pk, item["quantity"]) for item in self.items]
