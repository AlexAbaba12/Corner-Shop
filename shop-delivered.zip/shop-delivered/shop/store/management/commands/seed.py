from decimal import Decimal

from django.core.management.base import BaseCommand
from django.utils.text import slugify

from store.models import Category, Product

DEMO = {
    "Kitchen": [
        ("Cast iron skillet, 10 inch", "Pre-seasoned and heavy enough to hold heat for a proper sear.", "34.00", 25),
        ("Pour-over coffee set", "Glass carafe, steel filter, and a gooseneck kettle.", "48.50", 14),
        ("Hand-thrown mug", "Stoneware, 350 ml, dishwasher safe.", "16.00", 60),
        ("Bread knife", "Serrated 8 inch blade with a walnut handle.", "29.90", 18),
    ],
    "Desk": [
        ("Adjustable monitor riser", "Bamboo top, fits a laptop underneath.", "39.00", 30),
        ("Mechanical keyboard", "75% layout, hot-swappable switches.", "89.00", 12),
        ("Cable organizer set", "Eight silicone clips and a cable sleeve.", "9.50", 120),
        ("Desk lamp, warm white", "Dimmable LED with a weighted base.", "42.00", 20),
    ],
    "Outdoors": [
        ("Insulated bottle, 750 ml", "Keeps drinks cold for 24 hours or hot for 12.", "27.00", 45),
        ("Packable rain jacket", "Folds into its own pocket; fully taped seams.", "64.00", 9),
        ("Trail daypack, 22 L", "Padded back panel and a hip belt pocket.", "58.00", 16),
        ("Headlamp", "300 lumens, USB-C rechargeable.", "21.00", 0),
    ],
}


class Command(BaseCommand):
    help = "Create demo categories and products (safe to run more than once)."

    def handle(self, *args, **options):
        created = 0
        for category_name, products in DEMO.items():
            category, _ = Category.objects.get_or_create(
                name=category_name, defaults={"slug": slugify(category_name)}
            )
            for name, description, price, stock in products:
                _, was_created = Product.objects.get_or_create(
                    name=name,
                    defaults={
                        "category": category,
                        "description": description,
                        "price": Decimal(price),
                        "stock": stock,
                    },
                )
                created += int(was_created)
        self.stdout.write(self.style.SUCCESS(f"Seed complete: {created} new products."))
