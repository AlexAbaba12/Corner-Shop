from django.conf import settings

from .cart import Cart
from .models import CustomerProfile


def storefront(request):
    profile = None
    if request.user.is_authenticated:
        try:
            profile = request.user.customer_profile
        except CustomerProfile.DoesNotExist:
            pass
    return {
        "store_name": settings.STORE_NAME,
        "currency": settings.CURRENCY_SYMBOL,
        "cart_count": len(Cart(request)),
        "customer_profile": profile,
        "support_email": settings.SUPPORT_EMAIL,
    }
