from rest_framework import filters, generics, mixins, status, viewsets
from rest_framework.authtoken.models import Token
from rest_framework.decorators import action
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response

from store.models import Category, Order, Product
from store.services import OrderError, cancel_order, mark_paid

from .permissions import IsAdminOrReadOnly
from .serializers import (
    CategorySerializer,
    OrderSerializer,
    ProductSerializer,
    RegisterSerializer,
)


class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    lookup_field = "slug"
    pagination_class = None


class ProductViewSet(viewsets.ModelViewSet):
    """Public catalog. Staff users can also create, edit, and delete products.

    Query params: `search`, `category` (slug), `in_stock=true`, `ordering` (price, -price, name, created).
    """

    serializer_class = ProductSerializer
    permission_classes = [IsAdminOrReadOnly]
    lookup_field = "slug"
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ["name", "description"]
    ordering_fields = ["price", "name", "created"]

    def get_queryset(self):
        queryset = Product.objects.select_related("category")
        user = self.request.user
        if not (user and user.is_staff):
            queryset = queryset.filter(is_active=True)
        category = self.request.query_params.get("category")
        if category:
            queryset = queryset.filter(category__slug=category)
        if self.request.query_params.get("in_stock", "").lower() in {"1", "true", "yes"}:
            queryset = queryset.filter(stock__gt=0)
        return queryset


class OrderViewSet(
    mixins.CreateModelMixin,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    viewsets.GenericViewSet,
):
    """The signed-in user's orders. POST to place an order; stock is reserved immediately."""

    serializer_class = OrderSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        if getattr(self, "swagger_fake_view", False):
            return Order.objects.none()
        return Order.objects.filter(user=self.request.user).prefetch_related("items__product")

    def _fresh(self, order):
        return self.get_serializer(self.get_queryset().get(pk=order.pk)).data

    @action(detail=True, methods=["post"])
    def pay(self, request, pk=None):
        """Mark a pending order as paid. Placeholder for a real payment provider."""
        order = self.get_object()
        try:
            mark_paid(order)
        except OrderError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(self._fresh(order))

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        """Cancel a pending order and return its items to stock."""
        order = self.get_object()
        try:
            cancel_order(order)
        except OrderError as exc:
            return Response({"detail": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(self._fresh(order))


class RegisterView(generics.CreateAPIView):
    """Create an account and receive an API token."""

    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        token, _ = Token.objects.get_or_create(user=user)
        return Response({"username": user.username, "token": token.key}, status=status.HTTP_201_CREATED)
