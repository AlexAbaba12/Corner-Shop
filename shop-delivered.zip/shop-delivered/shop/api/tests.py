from decimal import Decimal

from django.contrib.auth import get_user_model
from rest_framework.test import APITestCase

from store.models import Category, Product

User = get_user_model()

SHIPPING = {
    "full_name": "Ada Buyer",
    "email": "ada@example.com",
    "address": "1 Main St",
    "city": "Springfield",
    "postal_code": "12345",
}


class ApiTests(APITestCase):
    def setUp(self):
        self.category = Category.objects.create(name="Desk", slug="desk")
        self.product = Product.objects.create(
            category=self.category, name="Lamp", price=Decimal("42.00"), stock=3
        )

    def test_api_root_serves_swagger_ui(self):
        response = self.client.get("/api/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "swagger-ui")

    def test_catalog_is_public(self):
        response = self.client.get("/api/products/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data["results"][0]["slug"], "lamp")

    def test_search_and_category_filter(self):
        self.assertEqual(self.client.get("/api/products/?search=lamp").data["count"], 1)
        self.assertEqual(self.client.get("/api/products/?category=nope").data["count"], 0)

    def test_only_staff_can_create_products(self):
        payload = {"name": "Desk mat", "price": "15.00", "stock": 10, "category": self.category.pk}
        user = User.objects.create_user("ada", password="pw-12345-xyz")
        self.client.force_authenticate(user)
        self.assertEqual(self.client.post("/api/products/", payload).status_code, 403)
        staff = User.objects.create_user("boss", password="pw-12345-xyz", is_staff=True)
        self.client.force_authenticate(staff)
        response = self.client.post("/api/products/", payload)
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.data["slug"], "desk-mat")

    def test_register_then_order_then_cancel(self):
        response = self.client.post(
            "/api/auth/register/",
            {"username": "newbie", "email": "n@example.com", "password": "a-long-pass-123"},
        )
        self.assertEqual(response.status_code, 201)
        self.client.credentials(HTTP_AUTHORIZATION=f"Token {response.data['token']}")

        order = self.client.post(
            "/api/orders/",
            {**SHIPPING, "items": [{"product": self.product.pk, "quantity": 2}]},
            format="json",
        )
        self.assertEqual(order.status_code, 201)
        self.assertEqual(order.data["total"], "84.00")
        self.product.refresh_from_db()
        self.assertEqual(self.product.stock, 1)

        cancelled = self.client.post(f"/api/orders/{order.data['id']}/cancel/")
        self.assertEqual(cancelled.status_code, 200)
        self.assertEqual(cancelled.data["status"], "cancelled")
        self.product.refresh_from_db()
        self.assertEqual(self.product.stock, 3)

    def test_ordering_more_than_stock_fails(self):
        user = User.objects.create_user("ada", password="pw-12345-xyz")
        self.client.force_authenticate(user)
        response = self.client.post(
            "/api/orders/",
            {**SHIPPING, "items": [{"product": self.product.pk, "quantity": 9}]},
            format="json",
        )
        self.assertEqual(response.status_code, 400)

    def test_orders_require_auth(self):
        self.assertIn(self.client.get("/api/orders/").status_code, (401, 403))
